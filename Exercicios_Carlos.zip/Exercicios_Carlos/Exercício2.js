document.addEventListener('DOMContentLoaded', () => {
    const resultado = 9 - 4 * 9 / 3 + 6 / 2;
    document.getElementById('resultado').textContent = `O resultado é: ${resultado}`;
});
