document.addEventListener('DOMContentLoaded', () => {
    const resultado = (7 - 2) + 9 / (2 + 1) * 8;
    document.getElementById('resultado').textContent = `O resultado é: ${resultado}`;
});
