document.addEventListener('DOMContentLoaded', () => {
    const resultado = (5 + 3) * 5 / 2 + 8 * 3;
    document.getElementById('resultado').textContent = `O resultado é: ${resultado}`;
});
