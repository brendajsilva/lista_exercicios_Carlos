document.addEventListener('DOMContentLoaded', function() {
    let resultado = 9 - 4 * 9 / 3 + 6 / 2;
    document.getElementById('resultado').textContent = resultado;
});
